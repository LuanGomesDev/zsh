# zsh
source "${0:A:h}/emoji-cli.zsh" 2>/dev/null || :
