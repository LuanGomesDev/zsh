# Change Log

All notable changes to this project will be documented in this file.
This project adheres to [b4b4r07/emoji-cli - GitHub](https://github.com/b4b4r07/emoji-cli).

This Change Log is based on [KeepaChangelog](keepachangelog.com).

## [v0.2.0] - 2015-10-28
### Added
- Add new feature "fuzzy match"


## [v0.1.0] - 2015-10-20
### Released
- Release stable version